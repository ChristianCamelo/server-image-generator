'use strict';


/**
 * Iniciar sesión
 * Endpoint para iniciar sesión de usuario
 *
 * body Login_body 
 * returns inline_response_200
 **/
exports.loginPOST = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "message" : "Sesión iniciada correctamente"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Obtener mensajes
 * Endpoint para obtener mensajes
 *
 * returns inline_response_200_2
 **/
exports.messagesGET = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "message" : "Mensajes obtenidos correctamente"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Crear mensaje
 * Endpoint para crear un nuevo mensaje
 *
 * body Messages_body 
 * returns inline_response_200_3
 **/
exports.messagesPOST = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "message" : "Mensaje creado correctamente"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Registrar usuario
 * Endpoint para registrar un nuevo usuario
 *
 * body Register_body 
 * returns inline_response_200_1
 **/
exports.registerPOST = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "message" : "Usuario registrado correctamente"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

